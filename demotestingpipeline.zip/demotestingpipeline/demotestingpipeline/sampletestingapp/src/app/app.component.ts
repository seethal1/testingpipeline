import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'sampletestingapp';
  interestRate = 675;
  firstNum=10;
  secondNum=20;
  result:number=this.firstNum+this.secondNum;

  greetUser(){
    return 'Welcome user';
  }
}
